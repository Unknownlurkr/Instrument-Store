﻿namespace Instruments
{
    internal class ApplicationDbContext
    {
    }
}